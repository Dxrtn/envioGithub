import login
import menu

if __name__ == "__main__":
    if login.login():
        menu.menu()
    else:
        print("Encerrando...")
