import getpass
import bcrypt
from data import conectar
from utils import *

limpar_tela()

def login():
    print("\n--- LOGIN ---")
    usuario = input("Usuário: ")
    senha = getpass.getpass("Senha: ").encode()

    con = conectar()
    cur = con.cursor()

    cur.execute("SELECT senha FROM usuarios WHERE usuario = %s", (usuario,))
    row = cur.fetchone()

    if not row:
        print("Usuário não encontrado.\n")
        return False

    senha_hash = row[0].encode()

    if bcrypt.checkpw(senha, senha_hash):
        limpar_tela()
        print("Login realizado com sucesso!\n")
        return True
    else:
        print("Senha incorreta.\n")
        return False
