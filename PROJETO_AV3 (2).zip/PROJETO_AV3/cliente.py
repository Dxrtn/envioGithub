from data import conectar
import veiculo
from utils import *

def cadastrar_cliente():
    print("\n--- CADASTRAR CLIENTE ---")

    nome = obrigatorio("Nome: ")
    telefone = obrigatorio("Telefone: ")
    email = obrigatorio("Email: ")
    endereco = obrigatorio("Endereço: ")

    con = conectar()
    cur = con.cursor()

    sql = """
    INSERT INTO Cliente (nome, telefone, email, endereco)
    VALUES (%s, %s, %s, %s)
    """

    cur.execute(sql, (nome, telefone, email, endereco))
    con.commit()

    print("Cliente cadastrado com sucesso!\n")
    cur.close()
    con.close()


def listar_clientes():
    print("\n--- LISTA DE CLIENTES ---")
    con = conectar()
    cur = con.cursor()

    cur.execute("SELECT * FROM Cliente ORDER BY id_cliente")
    clientes = cur.fetchall()

    if len(clientes) == 0:
        print("Não existem clientes cadastrados no momento.")
        return
        
    for c in clientes:
        id_cliente, nome, telefone, email, endereco = c

        print(f"\nCliente de ID: {id_cliente}\n")
        print(f"Nome: {nome}")
        print(f"Telefone: {telefone}")
        print(f"Email: {email}")
        print(f"Endereco: {endereco}")

    cur.close()
    con.close()
    print()


def atualizar_cliente():
    print("\n--- ATUALIZAR CLIENTE ---")
    listar_clientes()

    idc = input("ID do cliente a atualizar (0 para cancelar): ")

    if idc == "0":
        print("Atualização cancelada.\n")
        return

    novo_nome = input("Novo nome: ")
    novo_telefone = input("Novo telefone: ")
    novo_email = input("Novo email: ")
    novo_endereco = input("Novo endereço: ")

    con = conectar()
    cur = con.cursor()

    cur.execute("""
        UPDATE Cliente
        SET nome = %s,
            telefone = %s,
            email = %s,
            endereco = %s
        WHERE id_cliente = %s
    """, (novo_nome, novo_telefone, novo_email, novo_endereco, idc))

    con.commit()
    print("Cliente atualizado com sucesso!\n")

    cur.close()
    con.close()


def excluir_cliente():
    listar_clientes()
    idc = input("ID do cliente a excluir: ")

    con = conectar()
    cur = con.cursor()

    # Verificar veículos relacionados
    cur.execute("""
        SELECT id_veiculo, modelo, placa
        FROM Veiculo
        WHERE id_cliente = %s
    """, (idc,))
    veiculos = cur.fetchall()

    if veiculos:
        print("\nATENÇÃO: Este cliente possui veículos:")
        for v in veiculos:
            print(v)

        escolha = input("\nExcluir TODOS os veículos (e OS/serviços relacionados)? (s/n): ").strip().lower()
        if escolha != 's':
            print("Exclusão cancelada.\n")
            return

        for v in veiculos:
            veiculo.excluir_veiculo_confirmando(v[0])

    # Excluir cliente
    cur.execute("DELETE FROM Cliente WHERE id_cliente = %s", (idc,))
    con.commit()

    print("Cliente excluído!\n")

    cur.close()
    con.close()
