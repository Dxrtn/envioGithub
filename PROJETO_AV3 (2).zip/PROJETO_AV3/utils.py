import os

def limpar_tela():
    os.system('cls' if os.name == 'nt' else 'clear')


def obrigatorio(texto):
    while True:
        valor = input(texto).strip()
        if valor == "":
            print("Este campo é obrigatório. Tente novamente.")
        else:
            return valor
