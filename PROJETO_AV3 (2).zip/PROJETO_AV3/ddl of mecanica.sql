--
-- PostgreSQL database dump
--

\restrict EMdSv3IfGjASsSLSdfZnWj3QAFHJZN5tEAAIfGrRl8tU0Oe2Cah6WC8Ia7HHyJv

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-11-25 19:44:51

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'LATIN1';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 219 (class 1259 OID 16471)
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    id_cliente integer NOT NULL,
    nome character varying(100) NOT NULL,
    telefone character varying(20),
    email character varying(100),
    endereco character varying(200)
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16476)
-- Name: cliente_id_cliente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cliente_id_cliente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cliente_id_cliente_seq OWNER TO postgres;

--
-- TOC entry 5025 (class 0 OID 0)
-- Dependencies: 220
-- Name: cliente_id_cliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cliente_id_cliente_seq OWNED BY public.cliente.id_cliente;


--
-- TOC entry 221 (class 1259 OID 16477)
-- Name: mecanico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mecanico (
    id_mecanico integer NOT NULL,
    nome character varying(100) NOT NULL,
    especialidade character varying(100)
);


ALTER TABLE public.mecanico OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 16482)
-- Name: mecanico_id_mecanico_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mecanico_id_mecanico_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mecanico_id_mecanico_seq OWNER TO postgres;

--
-- TOC entry 5026 (class 0 OID 0)
-- Dependencies: 222
-- Name: mecanico_id_mecanico_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mecanico_id_mecanico_seq OWNED BY public.mecanico.id_mecanico;


--
-- TOC entry 223 (class 1259 OID 16483)
-- Name: ordemservico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ordemservico (
    id_os integer NOT NULL,
    data_emissao date NOT NULL,
    status character varying(50) NOT NULL,
    id_cliente integer NOT NULL,
    id_veiculo integer NOT NULL,
    id_mecanico integer NOT NULL
);


ALTER TABLE public.ordemservico OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 16492)
-- Name: ordemservico_id_os_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ordemservico_id_os_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ordemservico_id_os_seq OWNER TO postgres;

--
-- TOC entry 5027 (class 0 OID 0)
-- Dependencies: 224
-- Name: ordemservico_id_os_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ordemservico_id_os_seq OWNED BY public.ordemservico.id_os;


--
-- TOC entry 225 (class 1259 OID 16493)
-- Name: servico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.servico (
    id_servico integer NOT NULL,
    descricao character varying(200) NOT NULL,
    valor numeric(10,2) NOT NULL,
    id_os integer
);


ALTER TABLE public.servico OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 16499)
-- Name: servico_id_servico_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.servico_id_servico_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.servico_id_servico_seq OWNER TO postgres;

--
-- TOC entry 5028 (class 0 OID 0)
-- Dependencies: 226
-- Name: servico_id_servico_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.servico_id_servico_seq OWNED BY public.servico.id_servico;


--
-- TOC entry 227 (class 1259 OID 16500)
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    usuario character varying(50) NOT NULL,
    senha character varying(100) NOT NULL
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 16506)
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_id_seq OWNER TO postgres;

--
-- TOC entry 5029 (class 0 OID 0)
-- Dependencies: 228
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- TOC entry 229 (class 1259 OID 16507)
-- Name: veiculo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.veiculo (
    id_veiculo integer NOT NULL,
    modelo character varying(100) NOT NULL,
    placa character varying(10) NOT NULL,
    ano integer,
    id_cliente integer NOT NULL
);


ALTER TABLE public.veiculo OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 16514)
-- Name: veiculo_id_veiculo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.veiculo_id_veiculo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.veiculo_id_veiculo_seq OWNER TO postgres;

--
-- TOC entry 5030 (class 0 OID 0)
-- Dependencies: 230
-- Name: veiculo_id_veiculo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.veiculo_id_veiculo_seq OWNED BY public.veiculo.id_veiculo;


--
-- TOC entry 4834 (class 2604 OID 16515)
-- Name: cliente id_cliente; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente ALTER COLUMN id_cliente SET DEFAULT nextval('public.cliente_id_cliente_seq'::regclass);


--
-- TOC entry 4835 (class 2604 OID 16516)
-- Name: mecanico id_mecanico; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mecanico ALTER COLUMN id_mecanico SET DEFAULT nextval('public.mecanico_id_mecanico_seq'::regclass);


--
-- TOC entry 4836 (class 2604 OID 16517)
-- Name: ordemservico id_os; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordemservico ALTER COLUMN id_os SET DEFAULT nextval('public.ordemservico_id_os_seq'::regclass);


--
-- TOC entry 4837 (class 2604 OID 16518)
-- Name: servico id_servico; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servico ALTER COLUMN id_servico SET DEFAULT nextval('public.servico_id_servico_seq'::regclass);


--
-- TOC entry 4838 (class 2604 OID 16519)
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- TOC entry 4839 (class 2604 OID 16520)
-- Name: veiculo id_veiculo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.veiculo ALTER COLUMN id_veiculo SET DEFAULT nextval('public.veiculo_id_veiculo_seq'::regclass);


--
-- TOC entry 5008 (class 0 OID 16471)
-- Dependencies: 219
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cliente (id_cliente, nome, telefone, email, endereco) FROM stdin;
11	Davi	82 99999-0101	davi.duarte@gmail.com	rua A, 200
12	Pedro	82 98888-7777	pedro.luz@hotmail.com	rua B, 300
13	Te�fanes	(10) 91234-5678	teo.ferreira@outlook.com	rua C, 700
\.


--
-- TOC entry 5010 (class 0 OID 16477)
-- Dependencies: 221
-- Data for Name: mecanico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mecanico (id_mecanico, nome, especialidade) FROM stdin;
2	joelson	trocas
3	tonho	pneus
4	vanison	filtragem
5	vanison	filtragem
\.


--
-- TOC entry 5012 (class 0 OID 16483)
-- Dependencies: 223
-- Data for Name: ordemservico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ordemservico (id_os, data_emissao, status, id_cliente, id_veiculo, id_mecanico) FROM stdin;
8	2025-11-25	Aberta	11	8	3
\.


--
-- TOC entry 5014 (class 0 OID 16493)
-- Dependencies: 225
-- Data for Name: servico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.servico (id_servico, descricao, valor, id_os) FROM stdin;
4	Troca de �leo	150.00	\N
6	Alinhamento	500.00	\N
9	Balanceamento	100.00	8
5	Checagem de frenagem	300.00	8
\.


--
-- TOC entry 5016 (class 0 OID 16500)
-- Dependencies: 227
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id, usuario, senha) FROM stdin;
3	admin	$2a$14$uBByux18x74TNXzSceFxHOfuCQ/2gP065saZS9nOnGgg2Ce83VmWG
\.


--
-- TOC entry 5018 (class 0 OID 16507)
-- Dependencies: 229
-- Data for Name: veiculo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.veiculo (id_veiculo, modelo, placa, ano, id_cliente) FROM stdin;
8	Bmw i3	QRL-7961	2023	11
\.


--
-- TOC entry 5031 (class 0 OID 0)
-- Dependencies: 220
-- Name: cliente_id_cliente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cliente_id_cliente_seq', 13, true);


--
-- TOC entry 5032 (class 0 OID 0)
-- Dependencies: 222
-- Name: mecanico_id_mecanico_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mecanico_id_mecanico_seq', 5, true);


--
-- TOC entry 5033 (class 0 OID 0)
-- Dependencies: 224
-- Name: ordemservico_id_os_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ordemservico_id_os_seq', 8, true);


--
-- TOC entry 5034 (class 0 OID 0)
-- Dependencies: 226
-- Name: servico_id_servico_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.servico_id_servico_seq', 9, true);


--
-- TOC entry 5035 (class 0 OID 0)
-- Dependencies: 228
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 3, true);


--
-- TOC entry 5036 (class 0 OID 0)
-- Dependencies: 230
-- Name: veiculo_id_veiculo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.veiculo_id_veiculo_seq', 9, true);


--
-- TOC entry 4841 (class 2606 OID 16522)
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (id_cliente);


--
-- TOC entry 4843 (class 2606 OID 16524)
-- Name: mecanico mecanico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mecanico
    ADD CONSTRAINT mecanico_pkey PRIMARY KEY (id_mecanico);


--
-- TOC entry 4845 (class 2606 OID 16526)
-- Name: ordemservico ordemservico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordemservico
    ADD CONSTRAINT ordemservico_pkey PRIMARY KEY (id_os);


--
-- TOC entry 4847 (class 2606 OID 16528)
-- Name: servico servico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servico
    ADD CONSTRAINT servico_pkey PRIMARY KEY (id_servico);


--
-- TOC entry 4849 (class 2606 OID 16530)
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- TOC entry 4851 (class 2606 OID 16532)
-- Name: usuarios usuarios_usuario_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_usuario_key UNIQUE (usuario);


--
-- TOC entry 4853 (class 2606 OID 16534)
-- Name: veiculo veiculo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.veiculo
    ADD CONSTRAINT veiculo_pkey PRIMARY KEY (id_veiculo);


--
-- TOC entry 4855 (class 2606 OID 16536)
-- Name: veiculo veiculo_placa_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.veiculo
    ADD CONSTRAINT veiculo_placa_key UNIQUE (placa);


--
-- TOC entry 4856 (class 2606 OID 16537)
-- Name: ordemservico ordemservico_id_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordemservico
    ADD CONSTRAINT ordemservico_id_cliente_fkey FOREIGN KEY (id_cliente) REFERENCES public.cliente(id_cliente);


--
-- TOC entry 4857 (class 2606 OID 16542)
-- Name: ordemservico ordemservico_id_mecanico_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordemservico
    ADD CONSTRAINT ordemservico_id_mecanico_fkey FOREIGN KEY (id_mecanico) REFERENCES public.mecanico(id_mecanico);


--
-- TOC entry 4858 (class 2606 OID 16547)
-- Name: ordemservico ordemservico_id_veiculo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ordemservico
    ADD CONSTRAINT ordemservico_id_veiculo_fkey FOREIGN KEY (id_veiculo) REFERENCES public.veiculo(id_veiculo);


--
-- TOC entry 4859 (class 2606 OID 16552)
-- Name: servico servico_id_os_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.servico
    ADD CONSTRAINT servico_id_os_fkey FOREIGN KEY (id_os) REFERENCES public.ordemservico(id_os);


--
-- TOC entry 4860 (class 2606 OID 16557)
-- Name: veiculo veiculo_id_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.veiculo
    ADD CONSTRAINT veiculo_id_cliente_fkey FOREIGN KEY (id_cliente) REFERENCES public.cliente(id_cliente);


-- Completed on 2025-11-25 19:44:51

--
-- PostgreSQL database dump complete
--

\unrestrict EMdSv3IfGjASsSLSdfZnWj3QAFHJZN5tEAAIfGrRl8tU0Oe2Cah6WC8Ia7HHyJv

