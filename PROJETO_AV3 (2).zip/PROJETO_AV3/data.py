import psycopg2

def conectar():
   try:
       conn = psycopg2.connect(
           dbname='oficina mecanica',
           user='postgres',
           password= 'dr230405',
           host= 'localhost',
           port= '5432',
           options="-c client_encoding=UTF8"
       )
       return conn
   except Exception as erro:
       print(f"Erro ao conectar com o banco de dados: {erro}")
       return None