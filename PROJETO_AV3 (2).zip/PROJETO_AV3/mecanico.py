# mecanico.py
from data import conectar
import ordem_servico
from utils import *


def cadastrar_mecanico():
    print("\n--- CADASTRAR MECÂNICO ---")
    nome = obrigatorio("Nome: ")
    especialidade = obrigatorio("Especialidade: ")

    con = conectar()
    cur = con.cursor()

    sql = """
    INSERT INTO Mecanico (nome, especialidade)
    VALUES (%s, %s)
    """

    cur.execute(sql, (nome, especialidade))
    con.commit()

    limpar_tela()
    print("Mecânico cadastrado!\n")

    cur.close()
    con.close()


def listar_mecanicos():
    print("\n--- LISTA DE MECÂNICOS ---")
    con = conectar()
    cur = con.cursor()

    cur.execute("SELECT * FROM Mecanico ORDER BY id_mecanico")
    mecanicos = cur.fetchall()

    if len(mecanicos) == 0:
        print("Não existem mecânicos cadastrados no momento.")
        return
        
    for m in mecanicos:
        id_mecanico, nome, especialidade = m

        print(f"\n Mecânico de ID: {id_mecanico}\n")
        print(f"Nome: {nome}")
        print(f"Especialidade: {especialidade}")


    cur.close()
    con.close()
    print()


def excluir_mecanico():
    listar_mecanicos()
    idm = input("ID do mecânico a excluir: ")

    # verifica OS vinculadas
    oss = ordem_servico.listar_os_por_mecanico(idm)
    if oss:
        print("\nExistem Ordens de Serviço vinculadas a este mecânico:")
        for o in oss:
            print(o)
        print("\nOpções:")
        print("1 - Reatribuir cada OS para outro mecânico")
        print("2 - Excluir todas as OS (e seus serviços)")
        print("0 - Cancelar")
        escolha = input("Escolha: ").strip()

        if escolha == "0":
            print("Exclusão cancelada.\n")
            return

        elif escolha == "1":
            listar_mecanicos()
            novo = input("ID do mecânico para reatribuir as OS: ")

            con = conectar()
            cur = con.cursor()
            cur.execute("UPDATE OrdemServico SET id_mecanico = %s WHERE id_mecanico = %s", (novo, idm))
            con.commit()
            cur.close()
            con.close()

            print("Ordens reatribuídas. Agora você pode excluir o mecânico.\n")

        elif escolha == "2":
            for o in oss:
                ordem_servico.excluir_os_por_id(o[0])

        else:
            print("Opção inválida. Exclusão cancelada.\n")
            return

    # agora exclui o mecânico
    con = conectar()
    cur = con.cursor()
    cur.execute("DELETE FROM Mecanico WHERE id_mecanico = %s", (idm,))
    con.commit()
    cur.close()
    con.close()
    print("Mecânico excluído!\n")
