# veiculo.py
from data import conectar
import cliente
import ordem_servico
from utils import *

def cadastrar_veiculo():
    print("\n--- CADASTRAR VEÍCULO ---")

    cliente.listar_clientes()
    id_cliente = obrigatorio("ID do cliente dono do veículo (0 para cancelar): ")

    if id_cliente == "0":
        limpar_tela()
        print("Cancelado.\n")
        return

    modelo = obrigatorio("Modelo: ")
    placa = obrigatorio("Placa: ")
    ano = obrigatorio("Ano: ")

    con = conectar()
    cur = con.cursor()

    sql = """
    INSERT INTO Veiculo (modelo, placa, ano, id_cliente)
    VALUES (%s, %s, %s, %s)
    """

    cur.execute(sql, (modelo, placa, ano, id_cliente))
    con.commit()

    print("Veículo cadastrado!\n")
    cur.close()
    con.close()


def listar_veiculos_completo():
    print("\n--- VEÍCULOS COM DADOS DO CLIENTE ---")
    con = conectar()
    cur = con.cursor()

    cur.execute("""
        SELECT v.id_veiculo,
               v.modelo,
               v.placa,
               v.ano,
               c.id_cliente,
               c.nome AS cliente
        FROM Veiculo v
        JOIN Cliente c ON v.id_cliente = c.id_cliente
        ORDER BY v.id_veiculo;
    """)

    veiculos = cur.fetchall()

    if len(veiculos) == 0:
        print("Não existem veículos cadastrados no momento.")
        return
        
    for v in veiculos:
        id_veiculo, modelo, placa, ano, id_cliente, nome = v

        print(f"\nDono do veículo: {nome} - ID = {id_cliente}\n")
        print(f"ID do veículo: {id_veiculo}")
        print(f"Modelo: {modelo}")
        print(f"Placa: {placa}")
        print(f"Ano: {ano}")

    cur.close()
    con.close()
    print()


def excluir_veiculo():
    listar_veiculos_completo()
    idv = input("ID do veículo a excluir (0 para cancelar): ").strip()
    if idv == "0":
        print("Exclusão cancelada.\n")
        return
    excluir_veiculo_confirmando(idv)


def excluir_veiculo_confirmando(idv):
    con = conectar()
    cur = con.cursor()

    # Verifica existência do veículo
    cur.execute("SELECT id_veiculo, modelo, placa FROM Veiculo WHERE id_veiculo = %s", (idv,))
    veic = cur.fetchone()
    if not veic:
        print(f"Veículo com id {idv} não encontrado.\n")
        cur.close()
        con.close()
        return

    cur.execute("SELECT id_os, data_emissao, status FROM OrdemServico WHERE id_veiculo = %s ORDER BY id_os", (idv,))
    oss = cur.fetchall()

    if oss:
        print("\nExistem Ordens de Serviço vinculadas a este veículo:")
        for o in oss:
            print(o)

        escolha = input("\nDeseja excluir TODAS essas Ordens de Serviço (e os serviços vinculados)? (s/n): ").strip().lower()
        if escolha != 's':
            print("Exclusão abortada. Primeiro remova as ordens de serviço.\n")
            cur.close()
            con.close()
            return

        for o in oss:
            ordem_servico.excluir_os_por_id(o[0])

    cur.execute("DELETE FROM Veiculo WHERE id_veiculo = %s", (idv,))
    con.commit()
    print("Veículo excluído!\n")

    cur.close()
    con.close()
