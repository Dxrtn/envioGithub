from data import conectar
from utils import *

def cadastrar_servico():
    print("\n--- CADASTRAR SERVIÇO ---")

    descricao = obrigatorio("Descrição (0 para cancelar): ")
    if descricao == "0":
        print("Cancelado.\n")
        return

    valor = obrigatorio("Valor: ")

    con = conectar()
    cur = con.cursor()

    sql = "INSERT INTO Servico (descricao, valor, id_os) VALUES (%s, %s, NULL)"
    cur.execute(sql, (descricao, valor))
    con.commit()

    print("Serviço cadastrado!\n")

    cur.close()
    con.close()


def listar_servicos_completo():
    print("\n--- SERVIÇOS (JOIN COMPLETO) ---")
    con = conectar()
    cur = con.cursor()

    cur.execute("""
        SELECT s.id_servico, s.descricao, s.valor,
               os.id_os, c.nome, v.modelo, v.placa
        FROM Servico s
        LEFT JOIN OrdemServico os ON s.id_os = os.id_os
        LEFT JOIN Cliente c ON os.id_cliente = c.id_cliente
        LEFT JOIN Veiculo v ON os.id_veiculo = v.id_veiculo
        ORDER BY s.id_servico;
    """)

    servicos = cur.fetchall()
    if not servicos:
        print("Nenhum serviço cadastrado.\n")
        return False
    else:
        for s in servicos:
            id_servico, descricao, valor, id_os, nome, modelo, placa = s

            print(f"\nID do serviço: {id_servico}\n")
            print(f"Descrição: {descricao}")
            print(f"valor: R${valor}")
            print(f"ID da OS vinculada: {id_os}")
            print(f"Cliente(s) vinculado(s): {nome}")
            print(f"Modelo e placa do(s) veículo(s) vinculado(s): {modelo} - {placa}")

    cur.close()
    con.close()


def excluir_servico_por_id():

    if listar_servicos_completo() == False:
        return
    
    id_s = input("ID do serviço a excluir (0 para cancelar): ")

    if id_s == "0":
        print("Exclusão cancelada.\n")
        return

    con = conectar()
    cur = con.cursor()

    cur.execute("DELETE FROM Servico WHERE id_servico = %s", (id_s,))
    con.commit()

    print("Serviço excluído!\n")

    cur.close()
    con.close()
