from data import conectar
import cliente
import veiculo
import mecanico
from utils import *

def listar_os_completo():
    print("\n--- ORDENS DE SERVIÇO ---")
    con = conectar()
    cur = con.cursor()

    cur.execute("""
        SELECT os.id_os, os.data_emissao, os.status,
               c.nome, v.modelo, v.placa, m.nome
        FROM OrdemServico os
        JOIN Cliente c ON os.id_cliente = c.id_cliente
        JOIN Veiculo v ON os.id_veiculo = v.id_veiculo
        JOIN Mecanico m ON os.id_mecanico = m.id_mecanico
        ORDER BY os.id_os;
    """)

    ordens = cur.fetchall()

    if len(ordens) == 0:
        print("Não existem ordens de serviços cadastradas")
        return False
    
    for os in ordens:
        print("\n-------------------------------")
        print(f"ID OS: {os[0]}")
        print(f"Data: {os[1]}")
        print(f"Status: {os[2]}")
        print(f"Cliente: {os[3]}")
        print(f"Veículo: {os[4]} ({os[5]})")
        print(f"Mecânico: {os[6]}")

        # mostrar serviços associados
        cur.execute("""
            SELECT id_servico, descricao, valor
            FROM Servico
            WHERE id_os = %s
        """, (os[0],))
        servicos = cur.fetchall()

        if servicos:
            print("Serviços:")
            for s in servicos:
                print(f" - {s[0]} | {s[1]} | R$ {s[2]}")
        else:
            print("Sem serviços vinculados.")

    print("\n")
    cur.close()
    con.close()


def abrir_os():
    print("\n--- ABRIR ORDEM DE SERVIÇO ---")

    cliente.listar_clientes()
    id_cliente = input("ID do cliente (0 para cancelar): ")
    if id_cliente == "0":
        print("Cancelado.\n")
        return

    veiculo.listar_veiculos_completo()
    id_veiculo = input("ID do veículo (0 para cancelar): ")
    if id_veiculo == "0":
        print("Cancelado.\n")
        return

    mecanico.listar_mecanicos()
    id_mecanico = input("ID do mecânico (0 para cancelar): ")
    if id_mecanico == "0":
        print("Cancelado.\n")
        return

    # Criar OS
    con = conectar()
    cur = con.cursor()

    sql = """
    INSERT INTO OrdemServico (data_emissao, status, id_cliente, id_veiculo, id_mecanico)
    VALUES (CURRENT_DATE, 'Aberta', %s, %s, %s)
    RETURNING id_os;
    """

    cur.execute(sql, (id_cliente, id_veiculo, id_mecanico))
    id_os_nova = cur.fetchone()[0]

    print(f"\nOS criada com ID: {id_os_nova}")

    # Vínculo de serviços existentes
    print("\n--- VINCULAR SERVIÇOS EXISTENTES (Opcional) ---")
    import servico
    servico.listar_servicos_completo()

    ids = input("IDs dos serviços a vincular (separados por vírgula, ou 0 para pular): ")

    if ids != "0":
        lista_ids = [s.strip() for s in ids.split(",")]
        for s_id in lista_ids:
            cur.execute("UPDATE Servico SET id_os = %s WHERE id_servico = %s", (id_os_nova, s_id))
        con.commit()
        print("Serviços vinculados!\n")

    cur.close()
    con.close()


def excluir_os_por_id(id_os):
    con = conectar()
    cur = con.cursor()

    cur.execute("DELETE FROM Servico WHERE id_os = %s", (id_os,))
    cur.execute("DELETE FROM OrdemServico WHERE id_os = %s", (id_os,))
    con.commit()

    print(f"OS {id_os} excluída!\n")

    cur.close()
    con.close()


def atualizar_status_os():
    if listar_os_completo() == False:
        return
    
    id_os = obrigatorio("ID da OS para alterar status (0 cancelar): ")

    if id_os == "0":
        print("Cancelado.\n")
        return

    print("""Selecione o novo status:
    1 - Aberta
    2 - Em andamento
    3 - Fechada
    """)
    op = obrigatorio("Escolha: ")

    status = {
        "1": "Aberta",
        "2": "Em andamento",
        "3": "Fechada"
    }.get(op)

    if not status:
        print("Opção inválida.\n")
        return

    con = conectar()
    cur = con.cursor()

    cur.execute("""
        UPDATE OrdemServico
        SET status = %s
        WHERE id_os = %s
    """, (status, id_os))

    con.commit()
    cur.close()
    con.close()

    print(f"Status da OS atualizado para {status}!\n")


def excluir_os():
    if listar_os_completo() == False:
        return
    id_os = input("ID da OS para excluir (0 para cancelar): ")

    if id_os == "0":
        print("Exclusão cancelada.\n")
        return

    excluir_os_por_id(id_os)