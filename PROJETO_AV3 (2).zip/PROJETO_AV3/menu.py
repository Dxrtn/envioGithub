# menu.py
import cliente
import veiculo
import mecanico
import servico
import ordem_servico
from utils import *


# CLIENTES
def menu_clientes():
    while True:
        print("""
---- MENU DE CLIENTES ----
1 - Cadastrar Cliente
2 - Listar Clientes
3 - Atualizar Cliente
4 - Excluir Cliente
0 - Voltar
""")
        op = input("Escolha: ")

        if op == "1":
            limpar_tela()
            cliente.cadastrar_cliente()
        elif op == "2":
            limpar_tela()
            cliente.listar_clientes()
        elif op == "3":
            limpar_tela()
            cliente.atualizar_cliente()
        elif op == "4":
            limpar_tela()
            cliente.excluir_cliente()
        elif op == "0":
            limpar_tela()
            break
        else:
            print("Opção inválida.\n")


# VEÍCULOS
def menu_veiculos():
    while True:
        print("""
---- MENU DE VEÍCULOS ----
1 - Cadastrar Veículo
2 - Listar Veículos (JOIN Cliente)
3 - Excluir Veículo
0 - Voltar
""")
        op = input("Escolha: ")

        if op == "1":
            limpar_tela()
            veiculo.cadastrar_veiculo()
        elif op == "2":
            limpar_tela()
            veiculo.listar_veiculos_completo()
        elif op == "3":
            limpar_tela()
            veiculo.excluir_veiculo()
        elif op == "0":
            limpar_tela()
            break
        else:
            print("Opção inválida.\n")



# MECÂNICOS
def menu_mecanicos():
    while True:
        print("""
---- MENU DE MECÂNICOS ----
1 - Cadastrar Mecânico
2 - Listar Mecânicos
3 - Excluir Mecânico
0 - Voltar
""")
        op = input("Escolha: ")

        if op == "1":
            limpar_tela()
            mecanico.cadastrar_mecanico()
        elif op == "2":
            limpar_tela()
            mecanico.listar_mecanicos()
        elif op == "3":
            limpar_tela()
            mecanico.excluir_mecanico()
        elif op == "0":
            limpar_tela()
            break
        else:
            print("Opção inválida.\n")


# SERVIÇOS
def menu_servicos():
    while True:
        print("""
---- MENU DE SERVIÇOS ----
1 - Cadastrar Serviço
2 - Listar Serviços (JOIN)
3 - Excluir Serviço
0 - Voltar
""")
        op = input("Escolha: ")

        if op == "1":
            limpar_tela()
            servico.cadastrar_servico()
        elif op == "2":
            limpar_tela()
            servico.listar_servicos_completo()
        elif op == "3":
            limpar_tela()
            servico.excluir_servico_por_id()
        elif op == "0":
            limpar_tela()
            break
        else:
            print("Opção inválida.\n")


# ORDENS DE SERVIÇO
def menu_os():
    while True:
        print("""
---- MENU DE ORDENS DE SERVIÇO ----
1 - Abrir Ordem de Serviço
2 - Listar OS (JOIN completo)
3 - Excluir Ordem de Serviço
4 - Atualizar status da OS
0 - Voltar
""")
        op = input("Escolha: ")

        if op == "1":
            limpar_tela()
            ordem_servico.abrir_os()
        elif op == "2":
            limpar_tela()
            ordem_servico.listar_os_completo()
        elif op == "3":
            limpar_tela()
            ordem_servico.excluir_os()
        elif op == "4":
            limpar_tela()
            ordem_servico.atualizar_status_os()
        elif op == "0":
            limpar_tela()
            break
        else:
            print("Opção inválida.\n")




# MENU PRINCIPAL
def menu():
    while True:
        print("""
====== MENU OFICINA ======
1 - Clientes
2 - Veículos
3 - Mecânicos
4 - Serviços
5 - Ordens de Serviço
0 - Sair
""")
        op = input("Escolha: ")

        if op == "1":
            limpar_tela()
            menu_clientes()
        elif op == "2":
            limpar_tela()
            menu_veiculos()
        elif op == "3":
            limpar_tela()
            menu_mecanicos()
        elif op == "4":
            limpar_tela()
            menu_servicos()
        elif op == "5":
            limpar_tela()
            menu_os()
        elif op == "0":
            limpar_tela()
            print("Saindo...\n")
            break
        else:
            limpar_tela()
            print("Opção inválida.\n")
